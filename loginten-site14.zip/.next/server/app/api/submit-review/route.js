var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/submit-review/route.js")
R.c("server/chunks/[externals]__0l8ei7u._.js")
R.c("server/chunks/_1nom5be._.js")
R.c("server/chunks/src_lib_supabase_0935d-b.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_submit-review_route_actions_081yfw-.js")
R.m(21706)
module.exports=R.m(21706).exports
