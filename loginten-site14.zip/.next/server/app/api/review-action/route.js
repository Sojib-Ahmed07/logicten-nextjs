var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/review-action/route.js")
R.c("server/chunks/[root-of-the-server]__1283-6t._.js")
R.c("server/chunks/src_lib_supabase_0935d-b.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_review-action_route_actions_0yyqj1s.js")
R.m(97277)
module.exports=R.m(97277).exports
