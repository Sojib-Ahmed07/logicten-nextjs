module.exports=[49032,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_review-action_route_actions_0yyqj1s.js.map