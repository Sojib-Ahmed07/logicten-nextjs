module.exports=[74588,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_submit-review_route_actions_081yfw-.js.map